# Simple conditional in Ukrainian

a = 1

якщо a == 1:
	друкувати ("Hello")
інакшеякщо a == 1:
	друкувати ("World")
інше:
	друкувати ("Didn't understand۔۔۔")