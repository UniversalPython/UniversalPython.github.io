# Convert this file to Urdu code using the --reverse flag!

something = 2

if something == 1:
	print ("Hello")
elif something == 2:
	print ("World")
else:
	print ("Didn't understand...")