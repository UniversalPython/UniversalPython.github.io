import pycnnun

def filter (input_str):
	return pycnnun.cn2num(input_str)

def unfilter (input_str):
	return pycnnun.num2cn(input_str)
