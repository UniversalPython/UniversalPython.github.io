#!/usr/bin/env python
"""
UrduPython.

Python, but in Urdu.
"""

__author__ = 'Saad Bazaz'
__credits__ = 'Grayhat'
__url__ = 'https://github.com/saadbazaz/UrduPython'

from .urdu_python import *
